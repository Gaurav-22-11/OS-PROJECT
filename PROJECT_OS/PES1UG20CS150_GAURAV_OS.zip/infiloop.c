#include <stdio.h>
void main()
{  
	int i = 10;
	for( ; ;)
	{
		printf("%d\n",i);
	}
}
